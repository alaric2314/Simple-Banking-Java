public class BankAccount {
    private double balance;

    public BankAccount(double balance) {
        this.balance = balance;
    }

    // Getter and Setter
    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }
}