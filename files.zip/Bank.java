public class Bank {
    public String bankName = "Simple Bank";

    public static void main(String[] args) {
        // Create BankAccounts
        BankAccount acc1 = new BankAccount(1000.0);
        BankAccount acc2 = new BankAccount(2500.0);

        // Create Customers and give them the accounts
        Customer user1 = new Customer("Alice", acc1);
        Customer user2 = new Customer("Bob", acc2);

        // Output to Console
        System.out.println("Bank: Simple Bank");
        System.out.println(user1.name + " has $" + user1.account.getBalance());
        System.out.println(user2.name + " has $" + user2.account.getBalance());

        // Compare Multiple Objects
        System.out.println("\n--- Comparison ---");
        if (user1.account.getBalance() > user2.account.getBalance()) {
            System.out.println(user1.name + " is richer!");
        } else {
            System.out.println(user2.name + " is richer!");
        }
    }
}